﻿#pragma comment(lib, "Shell32.lib")
#pragma comment(lib, "Shlwapi.lib")
#define IMGUI_IMPL_WIN32_DISABLE_GAMEPAD
#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include "helper_functions.h"
#include <d3d11.h>
#include <tchar.h>
#include <windows.h>
#include <string>
#include <shellapi.h> 
#include "texture_loader.h"
#include <TlHelp32.h>
#include <Shlwapi.h> 
#define IMGUI_USER_CONFIG "my_imgui_config.h"

ID3D11Device* g_pd3dDevice = nullptr;
static ID3D11DeviceContext* g_pd3dDeviceContext = nullptr;
static IDXGISwapChain* g_pSwapChain = nullptr;
static UINT g_ResizeWidth = 0, g_ResizeHeight = 0;
static ID3D11RenderTargetView* g_mainRenderTargetView = nullptr;
static bool g_isDragging = false;
static ImVec2 g_dragOffset;
static char processName[256] = "";
static bool showProcessList = false;
static std::vector<PROCESSENTRY32W> processList;
static ImVec2 popupPos;
static bool isProcessListInitialized = false;
static int currentItem = -1;
static bool wasComboClicked = false;
static bool isDragging = false;
static POINT lastPos = { 0, 0 };
ID3D11ShaderResourceView* discordLogo = nullptr;
int discord_logo_width = 0;
int discord_logo_height = 0;

struct DragState {
    bool isDragging = false;
    POINT lastPos = { 0, 0 };
} dragState;

struct DiscordButton {
    ImVec4 defaultColor = ImVec4(0.47f, 0.52f, 0.93f, 1.0f);  
    ImVec4 hoverColor = ImVec4(0.52f, 0.57f, 0.98f, 1.00f);    
    float size = 32.0f;                                        
} discordBtn;

bool CreateDeviceD3D(HWND hWnd);
void CleanupDeviceD3D();
void CreateRenderTarget();
void CleanupRenderTarget();
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
void SetupImGuiStyle();

// function inject dll
bool InjectDLL(DWORD processId, const char* dllPath) {
    HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, processId);
    if (hProcess == NULL) return false;

    LPVOID loadLibAddr = (LPVOID)GetProcAddress(GetModuleHandleA("kernel32.dll"), "LoadLibraryA");
    if (loadLibAddr == NULL) {
        CloseHandle(hProcess);
        return false;
    }

    LPVOID allocMemAddr = VirtualAllocEx(hProcess, NULL, strlen(dllPath) + 1, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (allocMemAddr == NULL) {
        CloseHandle(hProcess);
        return false;
    }

    if (!WriteProcessMemory(hProcess, allocMemAddr, dllPath, strlen(dllPath) + 1, NULL)) {
        VirtualFreeEx(hProcess, allocMemAddr, 0, MEM_RELEASE);
        CloseHandle(hProcess);
        return false;
    }

    HANDLE hThread = CreateRemoteThread(hProcess, NULL, 0, (LPTHREAD_START_ROUTINE)loadLibAddr, allocMemAddr, 0, NULL);
    if (hThread == NULL) {
        VirtualFreeEx(hProcess, allocMemAddr, 0, MEM_RELEASE);
        CloseHandle(hProcess);
        return false;
    }

    WaitForSingleObject(hThread, INFINITE);
    VirtualFreeEx(hProcess, allocMemAddr, 0, MEM_RELEASE);
    CloseHandle(hThread);
    CloseHandle(hProcess);
    return true;
}

void LoadCustomFont(ImGuiIO& io)
{
    ImFontConfig config;
    config.OversampleH = 2;
    config.OversampleV = 2;

    io.Fonts->AddFontFromFileTTF("fonts/Roboto-Regular.ttf", 14.0f, &config);

    static const ImWchar ranges[] = { 0x0020, 0x00FF, 0 }; // Basic Latin
    config.MergeMode = false;
    io.Fonts->AddFontFromFileTTF("fonts/Roboto-Regular.ttf", 28.0f, &config, ranges);
}

std::string GetExecutablePath() {
    char buffer[MAX_PATH];
    GetModuleFileNameA(nullptr, buffer, MAX_PATH);
    std::string::size_type pos = std::string(buffer).find_last_of("\\/");
    return std::string(buffer).substr(0, pos);
}

bool LoadDiscordLogo()
{
    char exePath[MAX_PATH];
    GetModuleFileNameA(NULL, exePath, MAX_PATH);

    char* lastSlash = strrchr(exePath, '\\');
    if (lastSlash)
        *(lastSlash + 1) = '\0';

    char fullPath[MAX_PATH];
    sprintf_s(fullPath, "%sdiscord_logo.png", exePath);

    char debugInfo[512];
    sprintf_s(debugInfo, "Trying to load texture from: %s", fullPath);
    MessageBoxA(NULL, debugInfo, "Debug Info", MB_OK);

    bool ret = LoadTextureFromFile(fullPath, &discordLogo, &discord_logo_width, &discord_logo_height);
    if (!ret)
    {
        MessageBoxA(NULL, "Failed to load Discord logo!", "Error", MB_OK);
        return false;
    }

    sprintf_s(debugInfo, "Texture loaded successfully!\nWidth: %d\nHeight: %d",
        discord_logo_width, discord_logo_height);
    MessageBoxA(NULL, debugInfo, "Success", MB_OK);

    return true;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    WNDCLASSEX wc = { sizeof(WNDCLASSEX) };
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
    wc.lpszMenuName = NULL;
    wc.lpszClassName = L"InjectorClass";
    RegisterClassEx(&wc);

    HWND hwnd = CreateWindowEx(
        0,
        L"InjectorClass",
        L"Injector",
        WS_POPUP,
        CW_USEDEFAULT, CW_USEDEFAULT,
        400, 300,
        nullptr,
        nullptr,
        wc.hInstance,
        nullptr
    );

    if (!CreateDeviceD3D(hwnd))
    {
        CleanupDeviceD3D();
        UnregisterClassW(wc.lpszClassName, wc.hInstance);
        return 1;
    }

    ShowWindow(hwnd, SW_SHOWDEFAULT);
    UpdateWindow(hwnd);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;

    ImFontConfig config;
    config.OversampleH = 1;
    config.OversampleV = 1;
    config.PixelSnapH = true;

    static const ImWchar ranges[] = {
        0x0020, 0x00FF, // Basic Latin + Latin Supplement
        0x0400, 0x052F, // Cyrillic + Cyrillic Supplement
        0,
    };

    std::string fontPath = GetExecutablePath() + "\\fonts\\Roboto-Regular.ttf";
    ImFont* font = io.Fonts->AddFontFromFileTTF(fontPath.c_str(), 16.0f, &config, ranges);
    if (font == nullptr) {
        MessageBoxA(NULL, ("Failed to load font from: " + fontPath).c_str(), "Font Loading Error", MB_OK | MB_ICONERROR);
        io.Fonts->AddFontDefault();
    }

    SetupImGuiStyle();

    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);

    static char processName[256] = "";
    static char dllPath[MAX_PATH] = "";
    bool done = false;

    LoadCustomFont(io);

    unsigned long long discord_texture = 0;  
    int discord_width = 0, discord_height = 0;

    ID3D11ShaderResourceView* srv = nullptr;
    if (LoadTextureFromFile("assets/images/discord_logo.png", &srv, &discord_width, &discord_height)) {
        discord_texture = reinterpret_cast<unsigned long long>(srv);
        discordLogo = srv; 
    }

    while (!done)
    {
        MSG msg;
        while (PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
            if (msg.message == WM_QUIT)
                done = true;
        }
        if (done)
            break;

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        static bool firstFrame = true;
        if (firstFrame) {
            RECT screen;
            GetWindowRect(GetDesktopWindow(), &screen);
            int screenW = screen.right - screen.left;
            int screenH = screen.bottom - screen.top;

            int windowW = 400;
            int windowH = 300;

            int posX = (screenW - windowW) / 2;
            int posY = (screenH - windowH) / 2;

            HWND hwnd = GetActiveWindow();
            SetWindowPos(hwnd, nullptr, posX, posY, windowW, windowH, SWP_NOZORDER);
            firstFrame = false;
        }

        {
            ImGui::SetNextWindowPos(ImVec2(0, 0));
            ImGui::SetNextWindowSize(ImGui::GetIO().DisplaySize);

            ImGui::Begin("Main Window", nullptr,
                ImGuiWindowFlags_NoDecoration |
                ImGuiWindowFlags_NoMove |
                ImGuiWindowFlags_NoBringToFrontOnFocus |
                ImGuiWindowFlags_NoResize);

            if (ImGui::IsMouseDragging(0) && ImGui::IsWindowHovered()) {
                HWND hwnd = GetActiveWindow();
                POINT currentPos;
                GetCursorPos(&currentPos);

                if (!dragState.isDragging) {
                    dragState.isDragging = true;
                    dragState.lastPos = currentPos;
                }

                int deltaX = currentPos.x - dragState.lastPos.x;
                int deltaY = currentPos.y - dragState.lastPos.y;

                RECT rect;
                GetWindowRect(hwnd, &rect);
                SetWindowPos(hwnd, nullptr,
                    rect.left + deltaX,
                    rect.top + deltaY,
                    0, 0,
                    SWP_NOSIZE | SWP_NOZORDER);

                dragState.lastPos = currentPos;
            }
            else {
                dragState.isDragging = false;
            }

            ImGui::TextColored(ImVec4(0.6f, 0.6f, 1.0f, 1.0f), "Process Name");
            ImGui::SetNextItemWidth(ImGui::GetWindowWidth() - 32);

            static char processName[256] = "";
            static std::vector<PROCESSENTRY32W> processList;
            static int currentItem = -1;
            static bool wasComboClicked = false;

            if (ImGui::BeginCombo("##process", processName)) {
                if (processList.empty()) {
                    processList = GetProcessList();
                }

                for (size_t i = 0; i < processList.size(); i++) {
                    char processNameA[256] = { 0 };
                    WideCharToMultiByte(CP_UTF8, 0, processList[i].szExeFile, -1,
                        processNameA, sizeof(processNameA), NULL, NULL);

                    bool is_selected = (currentItem == i);
                    if (ImGui::Selectable(processNameA, is_selected)) {
                        currentItem = i;
                        strcpy_s(processName, processNameA);
                    }

                    if (is_selected) {
                        ImGui::SetItemDefaultFocus();
                    }
                }
                ImGui::EndCombo();
            }
            else {
                processList.clear();
            }

            // DLL Path
            ImGui::TextColored(ImVec4(0.6f, 0.6f, 1.0f, 1.0f), "DLL Path");
            ImGui::SetNextItemWidth(ImGui::GetWindowWidth() - 32);
            static char dllPath[MAX_PATH] = "";
            ImGui::InputText("##dllpath", dllPath, sizeof(dllPath));

            // Browse button
            ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10);
            if (ImGui::Button("Browse DLL", ImVec2(120, 30))) {
                OPENFILENAMEA ofn;
                ZeroMemory(&ofn, sizeof(ofn));
                ofn.lStructSize = sizeof(ofn);
                ofn.hwndOwner = NULL;
                ofn.lpstrFile = dllPath;
                ofn.nMaxFile = sizeof(dllPath);
                ofn.lpstrFilter = "DLL Files\0*.dll\0All Files\0*.*\0";
                ofn.nFilterIndex = 1;
                ofn.lpstrFileTitle = NULL;
                ofn.nMaxFileTitle = 0;
                ofn.lpstrInitialDir = NULL;
                ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;

                if (GetOpenFileNameA(&ofn)) {
                    // Path is already in dllPath
                }
            }

            // INJECT button
            ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 20);
            float buttonWidth = 200;
            ImGui::SetCursorPosX((ImGui::GetWindowWidth() - buttonWidth) * 0.5f);
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.25f, 0.25f, 0.40f, 1.00f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.32f, 0.32f, 0.47f, 1.00f));
            if (ImGui::Button("INJECT", ImVec2(buttonWidth, 40))) {
                if (strlen(processName) > 0 && strlen(dllPath) > 0) {
                    wchar_t wProcessName[256];
                    MultiByteToWideChar(CP_UTF8, 0, processName, -1, wProcessName, 256);
                    DWORD processId = GetProcessIdByName(wProcessName);
                    if (processId != 0) {
                        if (InjectDLL(processId, dllPath)) {
                            MessageBoxA(NULL, "DLL successfully injected!", "Success", MB_OK | MB_ICONINFORMATION);
                        }
                        else {
                            MessageBoxA(NULL, "Failed to inject DLL!", "Error", MB_OK | MB_ICONERROR);
                        }
                    }
                    else {
                        MessageBoxA(NULL, "Process not found!", "Error", MB_OK | MB_ICONERROR);
                    }
                }
                else {
                    MessageBoxA(NULL, "Please fill in all fields!", "Error", MB_OK | MB_ICONWARNING);
                }
            }
            ImGui::PopStyleColor(2);

            // Build ID
            ImGui::SetCursorPosY(ImGui::GetWindowHeight() - 30);
            ImGui::SetCursorPosX(ImGui::GetWindowWidth() - 110);
            ImGui::TextColored(ImVec4(0.5f, 0.5f, 0.5f, 1.0f), "build by qxzxf");

            ImVec2 windowSize = ImGui::GetWindowSize();

            if (discordLogo) {
                ImGui::SetCursorPos(ImVec2(windowSize.x - 40, 150)); 
                ImVec2 size(24, 24);
                if (ImGui::ImageButton("discord_btn", (ImTextureID)(intptr_t)discordLogo, size)) {
                    ShellExecuteA(NULL, "open", "https://discord.gg/gnW5DKRZrh", NULL, NULL, SW_SHOWNORMAL);
                }
            }

            ImGui::End();
        }

        ImGui::Render();
        const float clear_color_with_alpha[4] = { 0.07f, 0.07f, 0.09f, 1.00f };
        g_pd3dDeviceContext->OMSetRenderTargets(1, &g_mainRenderTargetView, NULL);
        g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView, clear_color_with_alpha);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        g_pSwapChain->Present(1, 0);
    }

    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    CleanupDeviceD3D();
    DestroyWindow(hwnd);
    UnregisterClassW(wc.lpszClassName, wc.hInstance);

    if (discordLogo) {
        discordLogo->Release();
        discordLogo = nullptr;
    }

    return 0;
}

bool CreateDeviceD3D(HWND hWnd)
{
    DXGI_SWAP_CHAIN_DESC sd;
    ZeroMemory(&sd, sizeof(sd));
    sd.BufferCount = 2;
    sd.BufferDesc.Width = 0;
    sd.BufferDesc.Height = 0;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate.Numerator = 60;
    sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hWnd;
    sd.SampleDesc.Count = 1;
    sd.SampleDesc.Quality = 0;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    UINT createDeviceFlags = 0;
    D3D_FEATURE_LEVEL featureLevel;
    const D3D_FEATURE_LEVEL featureLevelArray[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0, };
    HRESULT res = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice, &featureLevel, &g_pd3dDeviceContext);
    if (res == DXGI_ERROR_UNSUPPORTED)
        res = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_WARP, nullptr, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice, &featureLevel, &g_pd3dDeviceContext);
    if (res != S_OK)
        return false;

    CreateRenderTarget();
    return true;
}

void CleanupDeviceD3D()
{
    CleanupRenderTarget();
    if (g_pSwapChain) { g_pSwapChain->Release(); g_pSwapChain = nullptr; }
    if (g_pd3dDeviceContext) { g_pd3dDeviceContext->Release(); g_pd3dDeviceContext = nullptr; }
    if (g_pd3dDevice) { g_pd3dDevice->Release(); g_pd3dDevice = nullptr; }
}

void CreateRenderTarget()
{
    ID3D11Texture2D* pBackBuffer;
    g_pSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));
    g_pd3dDevice->CreateRenderTargetView(pBackBuffer, nullptr, &g_mainRenderTargetView);
    pBackBuffer->Release();
}

void CleanupRenderTarget()
{
    if (g_mainRenderTargetView) { g_mainRenderTargetView->Release(); g_mainRenderTargetView = nullptr; }
}

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;

    switch (msg)
    {
    case WM_SIZE:
        if (wParam != SIZE_MINIMIZED)
        {
            g_ResizeWidth = LOWORD(lParam);
            g_ResizeHeight = HIWORD(lParam);
        }
        return 0;
    case WM_SYSCOMMAND:
        if ((wParam & 0xfff0) == SC_KEYMENU) 
            return 0;
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hWnd, msg, wParam, lParam);
}

void SetupImGuiStyle()
{
    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4* colors = style.Colors;

    colors[ImGuiCol_WindowBg] = ImVec4(0.06f, 0.06f, 0.08f, 0.95f);
    colors[ImGuiCol_FrameBg] = ImVec4(0.10f, 0.10f, 0.12f, 0.90f);
    colors[ImGuiCol_FrameBgHovered] = ImVec4(0.12f, 0.12f, 0.14f, 1.00f);
    colors[ImGuiCol_FrameBgActive] = ImVec4(0.14f, 0.14f, 0.16f, 1.00f);
    colors[ImGuiCol_Button] = ImVec4(0.25f, 0.25f, 0.40f, 1.00f);
    colors[ImGuiCol_ButtonHovered] = ImVec4(0.32f, 0.32f, 0.47f, 1.00f);
    colors[ImGuiCol_ButtonActive] = ImVec4(0.37f, 0.37f, 0.52f, 1.00f);
    colors[ImGuiCol_Text] = ImVec4(0.85f, 0.85f, 0.85f, 1.00f);
    colors[ImGuiCol_TextDisabled] = ImVec4(0.50f, 0.50f, 0.50f, 1.00f);

    style.WindowPadding = ImVec2(15, 15);
    style.WindowRounding = 4.0f;
    style.FramePadding = ImVec2(5, 5);
    style.FrameRounding = 3.0f;
    style.ItemSpacing = ImVec2(12, 8);
    style.ItemInnerSpacing = ImVec2(8, 6);
    style.ScrollbarSize = 15.0f;
    style.ScrollbarRounding = 9.0f;
    style.GrabMinSize = 5.0f;
    style.GrabRounding = 3.0f;
}