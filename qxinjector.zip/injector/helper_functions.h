#pragma once
#include <Windows.h>
#include <TlHelp32.h>
#include <vector>
#include <string>

std::vector<PROCESSENTRY32W> GetProcessList();
DWORD GetProcessIdByName(const wchar_t* processName);
bool InjectDLL(DWORD processId, const wchar_t* dllPath);
bool IsElevated();